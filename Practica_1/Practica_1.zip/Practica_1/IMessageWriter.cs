﻿using System;

namespace Practica_1
{
    public interface IMessageWriter
    {
        string WriteMessage(string message);
    }
}
