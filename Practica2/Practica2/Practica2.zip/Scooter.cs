﻿using Practica2;
using System;

public class Scooter : Vehicle
{
    public static string typeOfVehicle = "Scooter";
    public Scooter() : base(typeOfVehicle)
    {
    }

}
