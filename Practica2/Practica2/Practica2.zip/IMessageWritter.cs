﻿namespace Practica2
{
    interface IMessageWritter
    {
        string WriteMessage(string customMessage);
    }
}